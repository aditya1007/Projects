figure(1);
subplot(231);imagesc(prob_map);title('prob map');
subplot(232);imagesc(X);title('X');
subplot(233);imagesc(Y);title('Y');
subplot(234);imagesc(Z);title('Z');
subplot(235);imagesc(Xout);title('Xout');
subplot(236);imagesc(label_im);title('Ground truth');